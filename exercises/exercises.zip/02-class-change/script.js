console.info("Everything looks fine ✅.");
console.log("Open this script.js file and write your code...");

// Task: Select the div (blue box) in the index html and change its looks
// by adding a class (style information is still in style.css 👍)
