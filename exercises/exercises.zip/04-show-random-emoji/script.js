console.info("Everything looks fine ✅.");
console.log("Open this script.js file and write your code...");

// display a random emoji from this list:
const emojis = ["🐓", "🐈‍⬛", "🍊", "🥑", "👹", "🫀", "🦆", "🦎"];

// whenever the button "Show" is clicked.

// Hints:
// Select the button
// add a click handler (eventlistener)
// write a function to select a random emoji from the list
// display it on screen inside the '[data-js-emoji-box]'
