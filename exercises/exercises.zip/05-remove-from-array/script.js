console.info("Everything looks fine ✅.");
console.log("Open this script.js file and write your code...");

// remove the banana from the list and log the remaining list to the console
const fruits = ["🍊", "🍌", "🍏", "🥝"];
